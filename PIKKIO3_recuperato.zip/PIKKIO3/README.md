# PIKKIO 3

Progressiva evoluzione della PWA PIKKIO: portafoglio personale, quotazioni, conversione valutaria, notizie globali e analisi informativa.

## Funzioni presenti nel pacchetto
- Portafoglio salvato localmente sul dispositivo.
- Inserimento, modifica ed eliminazione degli strumenti.
- Importazione ed esportazione CSV (`ticker;nome;quantita;prezzo_medio`).
- Quotazioni tramite Alpha Vantage, con data e valuta dichiarate dal provider/mappatura del suffisso di mercato.
- Conversione in euro tramite Frankfurter, con tassi di riferimento BCE quando disponibili.
- Calcolo del valore di carico e della plus/minusvalenza stimata rispetto all'ultima quotazione disponibile.
- Feed di notizie GDELT e corrispondenze preliminari, non causali, con i titoli.
- Analisi AI facoltativa tramite OpenAI Responses API, eseguita sul server.
- Service worker: cache degli asset statici; API, quotazioni e notizie non vengono presentate come aggiornate offline.

## Avvio
Richiede Node.js 18 o superiore.
1. `npm install`
2. Copia `.env.example` in `.env` e configura `ALPHA_VANTAGE_API_KEY`; `OPENAI_API_KEY` è facoltativa.
3. `npm start`
4. Apri `http://localhost:3000`.

## Installazione Android
1. Pubblica la cartella su un hosting che supporti Node.js e HTTPS.
2. Imposta le variabili d'ambiente nell'hosting, non nel browser.
3. Apri l'indirizzo HTTPS in Chrome su Android e scegli **Installa app** o **Aggiungi a schermata Home**.

## Limiti e verifiche ancora necessarie
- Il portafoglio resta nel browser del singolo dispositivo: non esistono ancora account né sincronizzazione multi-dispositivo.
- Alpha Vantage può fornire dati ritardati/fine giornata e applica limiti variabili. La valuta è dedotta dal suffisso di mercato per i mercati mappati; suffissi non riconosciuti non vengono convertiti arbitrariamente. Verificare sempre ticker, mercato e valuta.
- Per ticker senza suffisso si presume una quotazione USA in USD: controllare che sia corretto per ogni strumento.
- I cambi Frankfurter sono tassi di riferimento, non tassi eseguibili in tempo reale.
- Se prezzo o cambio non sono disponibili, PIKKIO non inventa un valore.
- Le corrispondenze tra notizie e strumenti sono preliminari; non rappresentano causalità, raccomandazioni o ordini automatici.
- Prima della pubblicazione servono test con chiavi API reali, verifica privacy/backup, monitoraggio e test su Android. Il pacchetto non è ancora pubblicato.
